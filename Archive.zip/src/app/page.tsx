"use client";
import React, { useState } from "react";
import VideoPlayer from "./components/VideoPlayer";
import CaptionInput from "./components/CaptionInput";

const Home: React.FC = () => {
  const [videoUrl, setVideoUrl] = useState<string>("");
  const [captions, setCaptions] = useState<
    { text: string; startTime: number; endTime: number }[]
  >([]);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-center">Video Captioning Tool</h1>
      <input
        type="text"
        placeholder="Enter Video URL"
        value={videoUrl}
        onChange={(e) => setVideoUrl(e.target.value)}
        className="block w-full p-3 border rounded mb-4 shadow"
      />
      {videoUrl && <VideoPlayer videoUrl={videoUrl} captions={captions} />}
      <CaptionInput onCaptionsSubmit={setCaptions} />
    </div>
  );
};

export default Home;
