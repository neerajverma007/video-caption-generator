"use client";
import React from "react";

interface ControlsProps {
  videoRef: React.RefObject<HTMLVideoElement>;
}

const Controls: React.FC<ControlsProps> = ({ videoRef }) => {
  const handlePlayPause = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
      } else {
        videoRef.current.pause();
      }
    }
  };

  const handleSkip = (amount: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime += amount;
    }
  };

  return (
    <div className="mt-4 flex justify-center space-x-4">
      <button
        onClick={() => handleSkip(-10)}
        className="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900"
      >
        -10s
      </button>
      <button
        onClick={handlePlayPause}
        className="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900"
      >
        Play/Pause
      </button>
      <button
        onClick={() => handleSkip(10)}
        className="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900"
      >
        +10s
      </button>
    </div>
  );
};

export default Controls;
