"use client";
import React, { useRef, useState, useEffect } from "react";
import Controls from "./Controls";

interface Caption {
  text: string;
  startTime: number;
  endTime: number;
}

interface VideoPlayerProps {
  videoUrl: string;
  captions: Caption[];
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ videoUrl, captions }) => {
  const videoRef = useRef<HTMLVideoElement>(null); // Use only HTMLVideoElement here
  const [currentCaption, setCurrentCaption] = useState<string>("");

  useEffect(() => {
    const updateCaption = () => {
      if (videoRef.current) {
        const currentTime = videoRef.current.currentTime;
        const activeCaption = captions.find(
          (caption) =>
            currentTime >= caption.startTime && currentTime <= caption.endTime
        );
        setCurrentCaption(activeCaption ? activeCaption.text : "");
      }
    };

    const videoElement = videoRef.current;
    videoElement?.addEventListener("timeupdate", updateCaption);

    return () => {
      videoElement?.removeEventListener("timeupdate", updateCaption);
    };
  }, [captions]);

  return (
    <div className="relative w-full mb-5">
      <video
        ref={videoRef}
        src={videoUrl}
        controls
        className="w-full rounded-lg shadow-lg"
      />
      <Controls videoRef={videoRef as React.RefObject<HTMLVideoElement>} /> {/* Type assertion here */}
      {currentCaption && (
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 overlayText text-white p-2 rounded-md">
          {currentCaption}
        </div>
      )}
    </div>
  );
};

export default VideoPlayer;
