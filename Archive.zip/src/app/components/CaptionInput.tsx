"use client";
import React, { useState } from "react";

interface Caption {
  text: string;
  startTime: number;
  endTime: number;
}

interface CaptionInputProps {
  onCaptionsSubmit: (captions: Caption[]) => void;
}

const CaptionInput: React.FC<CaptionInputProps> = ({ onCaptionsSubmit }) => {
  const [captions, setCaptions] = useState<Caption[]>([]);
  const [text, setText] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");

  const handleAddCaption = () => {
    const start = parseFloat(startTime);
    const end = parseFloat(endTime);
    if (!text || isNaN(start) || isNaN(end) || start >= end) return;

    const newCaption = { text, startTime: start, endTime: end };
    setCaptions([...captions, newCaption]);
    setText("");
    setStartTime("");
    setEndTime("");
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg mt-6 border border-gray-200">
      <h2 className="text-2xl font-semibold mb-4 text-gray-800">Add Captions</h2>
      <textarea
        placeholder="Caption text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="block w-full p-3 border border-gray-300 rounded-md mb-4 transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
      <div className="flex space-x-2 mb-4">
        <input
          type="number"
          placeholder="Start time (seconds)"
          value={startTime}
          onChange={(e) => setStartTime(e.target.value)}
          className="flex-1 p-3 border border-gray-300 rounded-md transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <input
          type="number"
          placeholder="End time (seconds)"
          value={endTime}
          onChange={(e) => setEndTime(e.target.value)}
          className="flex-1 p-3 border border-gray-300 rounded-md transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
      <div className="flex space-x-2">
        <button
          onClick={handleAddCaption}
          className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-md transition duration-200 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Add Caption
        </button>
        <button
          onClick={() => onCaptionsSubmit(captions)}
          className="flex-1 bg-green-600 text-white px-4 py-2 rounded-md transition duration-200 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500"
        >
          Submit Captions
        </button>
      </div>
      <div className="mt-4">
        {captions.length > 0 ? (
          captions.map((caption, index) => (
            <div key={index} className="p-3 border border-gray-300 rounded-md mb-2 bg-gray-100">
              <strong className="text-gray-800 text">{caption.text}</strong> 
              <span className="text-gray-500 text"> (Start: {caption.startTime}s, End: {caption.endTime}s)</span>
            </div>
          ))
        ) : (
          <p className="text-gray-500">No captions added yet.</p>
        )}
      </div>
    </div>
  );
};

export default CaptionInput;
